Binary distribution of binutils/gcc/newlib for Freescale S12/S12X platforms

These binaries are built on extended versions of the SCz tools
binutils-2.18 with S12X and XGATE enhancements
gcc-3.3.6 with S12/S12X ldivmod and larith enhancements
newlib with 9s12x target

To install you first need to have installed CYGWIN onto your Windows machine.

Download from   http://www.cygwin.org/cygwin and install.

*unsure what packages are required *
Likely some of the 'devel' package such as 'make'

Once Cygwin is installed run it and get used to the command prompt.

cd /
tar xfz <path>/tools.tar.gz

Packaged by James Murray 29 Oct 2010
Source available from http://www.msextra.com/tools

